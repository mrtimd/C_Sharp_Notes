﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace ConsoleCRUDtoSQL
{
    class Program
    {
        static void Main(string[] args)
        {
            // Display current Foreground color
            Console.WriteLine("Default Foreground Color: {0}",
                                     Console.ForegroundColor);

            // Set the Foreground color to blue
            Console.ForegroundColor
                = ConsoleColor.Green;

            // Display current Foreground color
            Console.WriteLine("Changed Foreground Color: {0}",
                                    Console.ForegroundColor);
            //Setup endApp
            bool endApp = false;

            // Display title as the C# console calculator app.
            Console.WriteLine("C.R.U.D Operations#\r");
            Console.WriteLine("------------------------\n");
            while (!endApp)
            {
                
                // Ask the user to choose an option.
                Console.WriteLine("Choose an option from the following list:");
                //Console.WriteLine("\ti - Create New Student");
                //Console.WriteLine("\ts - Show All Students - As List");
               // Console.WriteLine("\tz - Show All Students - As Columns");
                Console.WriteLine("\tu - Update Student - Need Student ID");
                //Console.WriteLine("\td - Delete Student - Need Student ID");
                Console.WriteLine("\ta - About ConsoleCRUDtoSQL app");
                //Console.WriteLine("\td - Divide");
                Console.Write("Your option? ");

                // Use a switch statement to select the CRUD operation.
                switch (Console.ReadLine())
                {
                    

                    case "u":
                        try
                        {
                            Console.WriteLine("Opening Connection ...");

                            //open connection
                            //conn.Open();

                            Console.WriteLine("Connection successful!");
                            //endApp function to allow choices - if it works here
                            // bool uendApp = false;
                            //// Ask the user to choose which field Name, Email, Class - to update - maybe a nested SWITCH ?
                            Console.WriteLine("Update Student Record:");
                            Console.WriteLine("---------------------:");
                            Console.WriteLine("What needs updating:");
                            Console.WriteLine("\tn - Name");
                            Console.WriteLine("\te - Email");
                            Console.WriteLine("\tc - Class");
                            Console.WriteLine("\ts - Student ID");
                            Console.Write("Your option? ");
                            //while (!uendApp)
                            {

                                //SWITCH For each field - Name, Email, Class 
                                switch (Console.ReadLine())
                                {
                                    case "c":

                                        Console.WriteLine("Enter Student ID:");
                                        //ustudentid for variable name - be different from others
                                        string ustudentId = Console.ReadLine();

                                        Console.WriteLine("Enter Class:");
                                        //ustudentid for variable name - be different from others
                                        string uclass = Console.ReadLine();

                                        // Display the input value to the user
                                        Console.WriteLine("Student Id is: " + ustudentId + "Class is " + uclass);

                                        //Updating a single field (Class for test) - repeat for each field in a nested SWITCH - ha ha or ??

                                        StringBuilder ustrBuilder = new StringBuilder("UPDATE Student_details SET ");
                                        //Add the rest of the TSQL in proper syntax - quotes etc..
                                        ustrBuilder.AppendFormat("Class='{0}' WHERE StudentID = '{1}'", uclass, ustudentId);

                                        //Console.WriteLine(ustrBuilder);
                                        string sqlQuery = ustrBuilder.ToString();
                                        //using (SqlCommand command = new SqlCommand(sqlQuery, conn))

                                        //Execute SQL query and show rows affected to console
                                        {
                                            //int rowsAffected = command.ExecuteNonQuery(); //execute query and get updated row count
                                            //Console.WriteLine(rowsAffected + " row(s) updated");
                                        }
                                        // Wait for the user to respond before closing. - see endApp line 12 and 19
                                        //Console.Write("Press 'n' and Enter to close the app, or press any other key and Enter to choose another C.R.U.D. Operation: ");
                                        //if (Console.ReadLine() == "n") endApp = true;
                                        ustrBuilder.Clear(); // clear all the string
                                        break;
                                    //Next cases
                                    case "n":
                                        Console.WriteLine("Update Name");
                                        break;
                                    case "e":
                                        Console.WriteLine("Update Email");
                                        break;
                                    case "s":
                                        Console.WriteLine("Update Student ID");
                                        break;
                                }
                                //End Switch

                                //decoration line
                                Console.WriteLine("------------------------\n");

                                //// Wait for the user to respond before closing. - see endApp line 12 and 19
                                //Console.Write("Press 'n' and Enter to close the app, or press any other key and Enter to choose another C.R.U.D. Operation: ");
                                //if (Console.ReadLine() == "n") endApp = true;

                            }


                        }
                        catch (Exception e)
                        {
                            Console.WriteLine("Error: " + e.Message);
                        }
                        break;

                    
                    case "a":
                        Console.WriteLine("About ConsoleCRUDtoSQL\n");
                        Console.WriteLine("CREATE, READ, UPDATE, DELETE\n");
                        Console.WriteLine("From a C# .Net 5.0 Console App\n");
                        Console.WriteLine("Create Student table based on columns in the code.\n");
                        Console.WriteLine("Many Flaws to fix as training :)\n");
                        Console.WriteLine("Version 0.01\n");
                        Console.WriteLine("Copyright 2021\n");
                        break;

                }
                //End Switch

                //decoration line
                Console.WriteLine("------------------------\n");

                // Wait for the user to respond before closing. - see endApp line 12 and 19
                Console.Write("Press 'n' and Enter to close the app, or press any other key and Enter to choose another C.R.U.D. Operation: ");
                if (Console.ReadLine() == "n") endApp = true;

            }
        }
    }
}
