﻿using System;

namespace Lesson02
{
    class Program
    {
        //Create a class pg33 Programming Fundamentals
        static void Main(string[] args)
        {
            //Gets width from user
            Console.WriteLine("Enter rectangle width :");

            // Create a string w to get user input
            string w = Console.ReadLine();

            //repeat for length
            Console.WriteLine("Enter rectangle length :");
            string l = Console.ReadLine();

            //convert string input to double before sending to Rectangle.cs
            Rectangle rect = new Rectangle(Convert.ToDouble(w), Convert.ToDouble(l));
            double area = rect.GetArea();
            Console.WriteLine("Area of Rectangle: {0}", area);
        }
    }
}
