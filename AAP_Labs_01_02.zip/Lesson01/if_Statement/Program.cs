﻿using System;

namespace if_Statement
{
    class Program
    {
        //Page 12 Programming Fundamentals: 2st lab
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            int number1 = 10;
            int number2 = 20;
            if (number2 > number1)
            {
                Console.WriteLine("number2 is greater than number1");
            }
        }
    }
}
