﻿using System;

namespace IntroducingCS
{
    class Program
    {
        //Start here.. Search GET READY in pdf to find labs
        //Page 05 Programming Fundamentals: 1st lab
        //Create Solution called Lesson01 - Project name IntroducingCS
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
