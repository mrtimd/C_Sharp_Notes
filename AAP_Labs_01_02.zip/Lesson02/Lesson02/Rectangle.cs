﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lesson02
{
    class Rectangle
    {
        //first rectangle with constructor
        //private double length;
        //private double width;
        //public Rectangle(double l, double w)
        //{
        //    length = l;
        //    width = w;
        //}
        private double length;
        private double width;
        public double Length
        {
            get
            {
                return length;
            }
            set
            {
                if (value > 0.0)
                    length = value;
            }
        }
        public double Width
        {
            get
            {
                return width;
            }

            set
            {
                if (value > 0.0)
                    width = value;
            }
        }

        public double GetArea()
        {
            return length * width;
        }
    }
}
