﻿using System;

namespace Lesson02
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            //before modification p37

            //Rectangle rect = new Rectangle(10.0, 20.0);
            //double area = rect.GetArea();
            //Console.WriteLine("Area of Rectangle: {0}", area);

            //p37
            Rectangle rect = new Rectangle();
            rect.Length = 10.0;
            rect.Width = 20.0;
            double area = rect.GetArea();
            Console.WriteLine("Area of Rectangle: {0}", area);
        }
    }
}
